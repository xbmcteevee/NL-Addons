plugin.video.janlul
===================

XBMC plugin of Dutch streamsite Janlul

# Installation
1. Download the package as a zip
2. Put the zip on a place which is accessable by the XBMC
3. Go to settings > Addon
4. Install addon using zip
5. Select the zip file
6. Navigate to Videos > addons > Janlul streams
7. Green streams are online, red streams are offline